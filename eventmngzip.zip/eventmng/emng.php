<?php 
 
 include 'incl/header.php';
 include 'incl/nav.php';
 include 'sections/hero_carousel.php';
 include 'incl/footer.php';

?>