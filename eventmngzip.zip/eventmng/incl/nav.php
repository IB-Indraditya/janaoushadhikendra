<nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top" id="navbar-example2">
  <div class="container">
    <!-- Logo -->
    <a class="navbar-brand" href="#">
    evng
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav mx-auto">
        <a class="nav-link active me-2" aria-current="page">Home</a>        
        <a class="nav-link me-5" href="#">About Us</a>
        <a class="nav-link me-5" href="#">Our services</a>
        <a class="nav-link me-" href="#">Gallery</a>
        <a class="nav-link me-2" href="#">Testimonials.</a>
      </div>
      <a class="btn btn-primary">Contact us</a>
    </div>
  </div>
</nav>
<div data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" class="scrollspy-example bg-body-tertiary py-3 rounded-2" tabindex="0">